/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paneles;

import BD.DB_methods;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import tareafinalprogamacion.Empleado;

/**
 *
 * @author Aitor PC
 */
public class MainFrame extends JFrame{
    public static CardLayout cl;
    public static JPanel pl;
    public static Empleado emp_act;
    
    public MainFrame(){
        DB_methods.primLog("acarrenom01");
        setResizable(false);
        setTitle("Gestor");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 750);
        
        // Creamos el CardLayout y el JPanel para contener las pantallas
        cl = new CardLayout();
        pl = new JPanel(cl);
        
        p_LogIn plog = new p_LogIn();
        pl.add(plog,"Login");
        p_NuevoUs pnus = new p_NuevoUs();
        pl.add(pnus,"Nuevo");
        p_GestorPrin pges = new p_GestorPrin();
        pl.add(pges,"Gestor");
        p_GestorEmp pemp = new p_GestorEmp();
        pl.add(pemp,"Emp");
        Emp_Reg reg = new Emp_Reg();
        pl.add(reg,"RegEmp");
        Reg_Rep rep = new Reg_Rep();
        pl.add(rep,"RegRep");
        
        add(pl, BorderLayout.CENTER);        
        
    }

    public static void setEmp_act(Empleado emp_act) {
        MainFrame.emp_act = emp_act;
    }

    public static Empleado getEmp_act() {
        return emp_act;
    }
    
    
}
