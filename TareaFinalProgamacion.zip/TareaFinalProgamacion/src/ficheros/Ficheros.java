/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ficheros;

import java.util.List;

/**
 *
 * @author jorge
 */
public class Ficheros {

    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        //ejemplos de como se ejecutan todos
//        
//        
//          
//        //objetos
//        Proyecto pro=new Proyecto ("proyectoJorge", "trata sobre mi vida");
//        Objetos.escribirArchivoObjetos("ArchivoObjetos", pro);
//        //leemos el fichero, recuperamos la lista que nos devuelve y la imprimimos
//        List recuperada=Objetos.leerArchivoObjetos("ArchivoObjetos");
//
//        for (Object objeto: recuperada){
//            Proyecto proyec=(Proyecto)objeto;
//            System.out.println(proyec);
//        }
//    }
    
}
