/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareafinalprogamacion;

import java.time.LocalDate;

/**
 *
 * @author Aitor PC
 */
public class Empleado {
    private int id_empleado;
    private int id_departamento;
    private String nombre;
    private int edad;
    private LocalDate fecha_Inc;
    private char puesto;
    private String usName;
    private String pswd;
    private int primLog;

    public Empleado() {
    }

    public Empleado(int id_departamento, String nombre, int edad, char puesto, String usName, String pswd) {
        this.id_departamento = id_departamento;
        this.nombre = nombre;
        this.edad = edad;
        this.puesto = puesto;
        this.usName = usName;
        this.pswd = pswd;
    }
    
    public Empleado(int id_empleado, int id_departamento, String nombre, int edad, LocalDate fecha_Inc, char puesto, String usName, String pswd, int primLog) {
        this.id_empleado = id_empleado;
        this.id_departamento = id_departamento;
        this.nombre = nombre;
        this.edad = edad;
        this.fecha_Inc = fecha_Inc;
        this.puesto = puesto;
        this.usName = usName;
        this.pswd = pswd;
        this.primLog = primLog;
    }

    @Override
    public String toString() {
        return "id" + id_empleado + ", dep" + id_departamento + ", " + nombre + ", " + edad + "años , fecha_Inc: " + fecha_Inc + ", " + puesto + ", usName" + usName;
    }
    
    public int getId_empleado() {
        return id_empleado;
    }

    public int getId_departamento() {
        return id_departamento;
    }    

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public LocalDate getFecha_Inc() {
        return fecha_Inc;
    }

    public char getPuesto() {
        return puesto;
    }

    public String getUsName() {
        return usName;
    }

    public String getPswd() {
        return pswd;
    }

    public void setPrimLog() {
        this.primLog = 0;
    }
}
