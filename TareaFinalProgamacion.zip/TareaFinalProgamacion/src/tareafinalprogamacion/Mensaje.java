/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareafinalprogamacion;

/**
 *
 * @author aitor
 */
public class Mensaje {
    private int ID_Reporte;
    private int ID_Empleado;
    private int ID_Departamento;
    private String Rep_Titulo;
    private String Rep_Mensaje;
    private String Rep_Fecha;

    public Mensaje() {
    }

    public Mensaje(int ID_Reporte, int ID_Empleado, int ID_Departamento, String Rep_Titulo, String Rep_Mensaje, String Rep_Fecha) {
        this.ID_Reporte = ID_Reporte;
        this.ID_Empleado = ID_Empleado;
        this.ID_Departamento = ID_Departamento;
        this.Rep_Titulo = Rep_Titulo;
        this.Rep_Mensaje = Rep_Mensaje;
        this.Rep_Fecha = Rep_Fecha;
    }

    public int getID_Reporte() {
        return ID_Reporte;
    }

    public void setID_Reporte(int ID_Reporte) {
        this.ID_Reporte = ID_Reporte;
    }

    public int getID_Empleado() {
        return ID_Empleado;
    }

    public void setID_Empleado(int ID_Empleado) {
        this.ID_Empleado = ID_Empleado;
    }

    public int getID_Departamento() {
        return ID_Departamento;
    }

    public void setID_Departamento(int ID_Departamento) {
        this.ID_Departamento = ID_Departamento;
    }

    public String getRep_Titulo() {
        return Rep_Titulo;
    }

    public void setRep_Titulo(String Rep_Titulo) {
        this.Rep_Titulo = Rep_Titulo;
    }

    public String getRep_Mensaje() {
        return Rep_Mensaje;
    }

    public void setRep_Mensaje(String Rep_Mensaje) {
        this.Rep_Mensaje = Rep_Mensaje;
    }

    public String getRep_Fecha() {
        return Rep_Fecha;
    }

    public void setRep_Fecha(String Rep_Fecha) {
        this.Rep_Fecha = Rep_Fecha;
    }

    @Override
    public String toString() {
        return ID_Reporte + " ID_Empleado: " + ID_Empleado + "   |ID_Departamento=" + ID_Departamento + "   |Rep_Titulo=" + Rep_Titulo + "   |Rep_Fecha:" + Rep_Fecha + '}';
    }
    
    
}
