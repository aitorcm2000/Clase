/**
 * Aquí debería recogerse los metodos:
 *      1.Comprobacion de Usuario
 *      2.Insercion de Usuario
 *      3.Insercion de Score
 *      4.Query 10 mejores scores
 *      5.Scores del Usuario
 *      6.Mejor Score del Usuario
 */
package BD;

/**
 *
 * @author aitor
 */
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import tareafinalprogamacion.Empleado;


public class DB_methods {
    private static Connection c = DB_class.getInstance().getConnection();
    private static PreparedStatement ps;
    private static Statement s;
    private static ResultSet rs;
    
    /**
     * Coje el parametro de entrada
     * @param usName
     * y ejecuta una query buscando al menos una instancia de
     * un usuario cuyo DNI sea igual al insertado como parametro
     * @return
     */
    public static boolean usuarioExiste(String usName){
        String q= "SELECT COUNT(ID_Empleado) FROM empleados WHERE Emp_Nombre=?";
        try{
            ps=c.prepareStatement(q);
            ps.setString(1, usName);
            rs=ps.executeQuery();
            rs.next();
            if(rs.getInt(1)>0){return true;}
        }catch(SQLException ex){
            System.out.println("Failed to execute");
            System.err.println(ex.getMessage());
        }
        return false;
    }
    
    
    public static Empleado recogeEmp(String alias){
        Empleado emp=new Empleado();
        String q= "SELECT * FROM usuarios WHERE Alias=?";
        try{
            ps=c.prepareStatement(q);
            ps.setString(1, alias);
            rs=ps.executeQuery();
            while(rs.next()){
                emp= new Empleado(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), LocalDate.MIN, rs.getString(6).charAt(0), rs.getString(7), rs.getString(8));                
            }
            return emp;
        }catch(SQLException ex){
            System.out.println("Failed to execute");
            System.err.println(ex.getMessage());
            return new Empleado();
        }        
    }
    
    public static void insertUsuario(Empleado e){
        if(usuarioExiste(e.getUsName())!=true){
            String i="INSERT INTO empleados "
                    + "(ID_Departamento, Emp_Nombre, Emp_Edad, fecha_Inc,"
                    +" Emp_Puesto, Emp_usName, Emp_Pswd, primLog) VALUES(?,?,?,?,?,?,?,?)";                      //Statement preparado para la insercion de datos
            try{
                ps=c.prepareStatement(i);

                ps.setInt(1, e.getId_departamento());  //ID curso (Combobox UI)
                ps.setString(2, e.getNombre());  //Alias (Dato UI)
                ps.setInt(3, e.getEdad());      //Edad (Dato UI)
                ps.setDate(4, java.sql.Date.valueOf(LocalDate.now()));    //DNI usuario (Dato UI)
                ps.setString(5, ""+e.getPuesto());
                ps.setString(6, e.getUsName());
                ps.setString(7, e.getPswd());
                ps.setBoolean(8, true);
                
                ps.executeUpdate();
            }catch(SQLException ex){                    //La excepcion la dictamina MySQL, son errores de MySQL en general
                System.out.println("Fallo insertar usuario");
                System.err.println(ex.getMessage());
            }            
        }else{
            System.err.println("Usuario ya existe");
        }
    }
        
        
    public static int buscaID_Dep(String dep){
        String q= "SELECT ID_Departamento FROM departamentos WHERE Dep_Nombre=?";
        try{
            ps=c.prepareStatement(q);
            ps.setString(1, dep);
            rs=ps.executeQuery();
            rs.next();
            return Integer.parseInt(rs.getString(1));
        }catch(SQLException ex){
            System.out.println("Fallo buscaID_Dep");
            System.err.println(ex.getMessage());
            return 1;
        }  
    }
    
    public static int buscaID_Aula(String aula){
        String q= "SELECT ID_Aula FROM aulas WHERE Nombre_Aula=?";
        try{
            ps=c.prepareStatement(q);
            ps.setString(1, aula);
            rs=ps.executeQuery();
            rs.next();
            return Integer.parseInt(rs.getString(1));
        }catch(SQLException ex){
            System.out.println("Fallo buscaID_aula");
            System.err.println(ex.getMessage());
            return 1;
        }
    }
    
    public static int buscaID_Usuario(String alias){
        String q= "SELECT ID_Usuario FROM usuarios WHERE Alias=?";
        try{
            ps=c.prepareStatement(q);
            ps.setString(1, alias);
            rs=ps.executeQuery();
            rs.next();
            return Integer.parseInt(rs.getString(1));
        }catch(SQLException ex){
            System.out.println("Fallo buscaID_Usuario");
            System.err.println(ex.getMessage());
            return 1;
        }
    }
    
    public static List<Empleado> getEmpleados(){
        List<Empleado> emp = new ArrayList();
        String q="SELECT * FROM empleados";

        try{
            s=c.createStatement();
            rs=s.executeQuery(q);
            while(rs.next()){
                Empleado e = new Empleado(rs.getInt(1), rs.getInt(2), rs.getString(3),
                        rs.getInt(4),rs.getDate(5).toLocalDate(), rs.getString(6).charAt(0),
                        rs.getString(7), rs.getString(8));
                emp.add(e);
                System.out.println(c);
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage());
        }
        return emp;
    }
    
    public static void usuarioPB(){
        String q="SELECT u.Alias,c.Nombre_Curso,a.Nombre_Aula,s.Puntos FROM scores s "  //1.Alias 2.Curso 3.Aula 4.Puntos
                +"INNER JOIN usuarios u ON u.DNI_usuario=s.DNI_usuario "
                +"INNER JOIN cursos c ON c.ID_curso=u.ID_Curso "
                +"INNER JOIN aulas a ON a.ID_aula=s.ID_Aula DESC WHERE u.DNI_usuario=?";
        int con=0;
        try{
            s=c.createStatement();
            rs=s.executeQuery(q);
            while(rs.next()){
                con++;
                System.out.println(con+" "+rs.getString(1)+" pts: "+rs.getInt(2));
            }
        }catch(SQLException ex){
            System.err.println(ex.getMessage());
        }
    }
    
}